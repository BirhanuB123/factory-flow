const mongoose = require('mongoose');

const MOVEMENT_TYPES = [
  'opening_balance',
  'receipt',
  'issue',
  'adjustment',
  'production_consume',
  'production_output',
  'production_issue',
  'production_return',
  'transfer_out',
  'transfer_in',
];

const StockMovementSchema = new mongoose.Schema({
  tenantId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Tenant',
    required: true,
    index: true,
  },
  product: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true,
    index: true,
  },
  location: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Location',
    default: null,
    index: true,
  },
  toLocation: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Location',
    default: null,
  },
  /** Positive = stock increase, negative = decrease */
  delta: {
    type: Number,
    required: true,
  },
  movementType: {
    type: String,
    enum: MOVEMENT_TYPES,
    required: true,
  },
  referenceType: {
    type: String,
    enum: ['ProductionJob', 'Product', 'Manual', 'PurchaseOrder', 'Shipment', 'Order', null],
    default: null,
  },
  referenceId: {
    type: mongoose.Schema.Types.ObjectId,
    default: null,
  },
  note: { type: String, default: '' },
  lotNumber: { type: String, default: '' },
  batchNumber: { type: String, default: '' },
  serialNumber: { type: String, default: '' },
  expirationDate: { type: Date, default: null },
  /** Snapshot of on-hand after this movement */
  balanceAfter: {
    type: Number,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

StockMovementSchema.index({ createdAt: -1 });
StockMovementSchema.index({ tenantId: 1, product: 1, createdAt: -1 });

module.exports = mongoose.model('StockMovement', StockMovementSchema);
module.exports.MOVEMENT_TYPES = MOVEMENT_TYPES;
