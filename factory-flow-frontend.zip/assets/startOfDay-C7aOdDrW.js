import{bq as r}from"./index-Byh7cohj.js";function a(o){const t=r(o);return t.setHours(0,0,0,0),t}export{a as s};
