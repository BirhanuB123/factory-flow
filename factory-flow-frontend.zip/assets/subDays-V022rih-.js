import{bn as a,bv as e}from"./index-Bksm0GnC.js";function n(r,t){const s=a(r);return isNaN(t)?e(r,NaN):(t&&s.setDate(s.getDate()+t),s)}function i(r,t){return n(r,-t)}export{n as a,i as s};
