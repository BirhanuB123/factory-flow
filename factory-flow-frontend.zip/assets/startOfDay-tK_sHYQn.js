import{bn as r}from"./index-Bksm0GnC.js";function a(o){const t=r(o);return t.setHours(0,0,0,0),t}export{a as s};
